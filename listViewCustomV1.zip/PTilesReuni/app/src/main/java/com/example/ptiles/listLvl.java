package com.example.ptiles;

import android.app.ListActivity;
import android.graphics.Typeface;
import android.renderscript.Sampler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.widget.Button;

public class listLvl extends AppCompatActivity {

     ListView lv;
     String[] tabNiveau = {"Guren no yumiya","Gurenge","Rumbling"};


    private Integer lvlimg[] = {
            R.drawable.snk1_img,
            R.drawable.demon_slayer1_img,
            R.drawable.snk7_img

    };

    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_lvl);


        lv = findViewById(R.id.lv);

        adapter = new ArrayAdapter(listLvl.this, R.layout.customlv,R.id.lvlname,tabNiveau);
        lv.setAdapter(adapter);


        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                Intent level = new Intent(listLvl.this,level.class);
                startActivity(level);
                switch (tabNiveau[i]) {
                    case "Guren no yumiya":
                        level.putExtra("niveau","snk1");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                        break;

                    case "Gurenge":
                        level.putExtra("niveau","demon_slayer1");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
                        break;

                    case "Rumbling":
                        level.putExtra("niveau","snk7");
                        startActivity(level);
                        overridePendingTransition(R.anim.fadein, R.anim.fadeout);

                        break;
                }


            }
        });



    }
}